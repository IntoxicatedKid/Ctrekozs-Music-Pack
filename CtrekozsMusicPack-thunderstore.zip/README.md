## Ctrekoz's Music Pack
A selection of musics by Ctrekoz.

Music and credit:  
Seija(replace): https://www.youtube.com/watch?v=9MD5JeGmdUk  
Junko(replace): https://www.youtube.com/watch?v=P84W6slVvz8  
Remilia(replace): https://www.youtube.com/watch?v=nP7Fbng6xFw  
Sanae(replace): https://www.youtube.com/watch?v=8ka7d6AVUFU

Lost Branch of Legend By Alioth Studio  
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746  